import React from 'react'
// import { Container } from 'react-bootstrap'
import { Container ,Paper,Button} from '@material-ui/core';
export default function Details() {
  return (
    <Container>

       

{Details.map(RestuarantDetails=>(
    <Paper elevation={6} style={{margin:"10px",padding:"15px", textAlign:"left"}} key={RestuarantDetails.restuarantname}>
   RestuarantName:{RestuarantDetails.restuarantName}<br/>
   FoodName:{RestuarantDetails.foodName}<br/>
   Location:{RestuarantDetails.location}<br/>
   Rating:{RestuarantDetails.rating}
  </Paper>
))
}

</Container>
    
  );
}
