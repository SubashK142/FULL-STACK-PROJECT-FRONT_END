



import './App.css';
import ColorSchemesExample from './Components/navigationber';
import Student from './Components/userscomponent';
// import UserComponent from './Components/userscomponent';
import Details from './Components/details';
function App() {
  return (
    <div>
    <ColorSchemesExample/>
    <Student/>
    
    </div>
  );
}

export default App;